Minimalist push configs to a Junos device using a user/password or using a ssh key.

vmx-filters-push.py:  pushes a ff.conf junos config

vmx-filters-delete.py: pushes the matching junos delete in set format

get-facts-nopass-sshkey.py: get informations on junos device using no password ssh key

get-facts-withpass-sshkey.py: get informations on junos device using a password protected ssh key (prompt for password)

